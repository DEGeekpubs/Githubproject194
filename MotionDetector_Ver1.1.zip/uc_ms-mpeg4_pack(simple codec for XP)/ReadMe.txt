A very old simple codec, but works good.
Intended for Windows XP.
Was downloaded from http://www.undercut.org/download/ 

It provides three Codecs with the following names:

Microsoft MPEG-4 Video Codec V1
Microsoft MPEG-4 Video Codec V2
Microsoft MPEG-4 Video Codec V3

Before running executable uc_ms-mpeg4_pack.exe check that this codec is not already
installed in the system. The simplest way to do this is to start MotionDetector.exe
and check available codecs in Menu Settings -> Video Compressor... Alternatively,
one can run utility sherlock2.0.exe. It will show the names of all available
in the sysem codecs with supplementary information that can be useful 
for troubleshooting. The utility can be downloaded from 
http://www.free-codecs.com/download/Sherlock_The_Codec_Detective.htm.

If you see these codecs - do nothing. They are already installed and can be used.

It can be that you will see the same codecs, but from another vendor, with slightly
different names. They can look like this:

Microsoft MPEG-4 VKI Codec V1
Microsoft MPEG-4 VKI Codec V2
Microsoft MPEG-4 VKI Codec V3

These are similar codecs, but they have different names, and if you want to install
codecs with classical names, these codecs with non-standard names should be removed
first. If this is not done, the new intalled codecs will not be visible. To remove
three old codecs, one should delete three keys in the Windows Regisrty. 
To do this, run "regedit". There, go to: hkey_local_machine -> software -> microsoft ->
windows nt -> current version -> drivers32 and there find three keys:
VIDC.MP42, VIDC.MP43 and VIDC.MPG4 associaled with mpg4c32.dll. DELETE all these keys. 

Then, run uc_ms-mpeg4_pack.exe.

If messages will appear, answer YES, except the case
when system will tell that the system files are replaced 
with unknown files and it wants to recover the old files.
In this case answer NO.