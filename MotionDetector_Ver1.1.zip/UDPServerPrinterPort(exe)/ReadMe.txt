Copy inpout32.dll to WINDOWS\System32\
In this case it will be available from all locations.

16.10.2020
The program is imported in Delphi 10.3.3.
Functionality has been tested.

It has been found that optional feature of lightening of LED connected to printer port 
works only in Win XP. The reason is that one should use non-signed by Microsoft 
port driver in Win 7 and Win 10.  Non-signed drivers should be allowed in Win 7 and win 10
in OS settings. This severely affects security. For this reason another test utility 
UDPServerSerialPort has been created. It uses sertified COM port driver and works well 
in all operating systems.
